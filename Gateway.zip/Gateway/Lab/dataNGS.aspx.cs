﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Gateway.Lab
{
    public partial class dataNGS : System.Web.UI.Page
    {
        public string RTSSID { get; set; }
        public string grpMember { get; set; }
        public DateTime libDate { get; set; }
        public string strLibDate;
        public DateTime runDate { get; set; }
        public string strRunDate;
        public string NGSID { get; set; }
        public bool blnAdd = true;

        protected void Page_Load(object sender, EventArgs e)
        {
            RTSSID = HttpUtility.UrlDecode(Request.QueryString["RTSSID"]);
            grpMember = System.Web.HttpContext.Current.Session["NIHID"].ToString();
            DateTime dateTime2;
            DateTime dateTime2a;

            //Check for NGS membership - redirect if not
            if (Session["group"].ToString() != "NGS")
            {
                Response.Redirect("viewNGS.aspx?RTSSID=" + RTSSID, true);
            }


            if (!IsPostBack)
            {
                string connString = ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString;
                string sqlString = "Select NGSID, Instrument, InvestigatorSample, LibStartDate, PreppedBy, LibType, SizeRange, AvgSize, TitrationAmt, SeqLength, Lane, IndexMID, RunStartDate, RunName, RefToUse FROM tblDataNGS WHERE RTSSID = @strID";
                SqlConnection sqlConn = new SqlConnection(connString);
                SqlCommand sqlComm = new SqlCommand(sqlString, sqlConn);
                sqlComm.Parameters.AddWithValue("@strID", RTSSID);
                sqlConn.Open();
                SqlDataReader reader = sqlComm.ExecuteReader();

                while (reader.Read())
                {
                    NGSID = reader.GetValue(0).ToString();
                    ddlInstrument.SelectedValue = reader.GetValue(1).ToString().Trim();
                    txtInvSample.Text = reader.GetValue(2).ToString();
                    strLibDate = reader.GetValue(3).ToString();
                    txtPrepBy.Text = reader.GetValue(4).ToString();
                    txtLibType.Text = reader.GetValue(5).ToString();
                    txtSizeRange.Text = reader.GetValue(6).ToString();
                    txtAvgSize.Text = reader.GetValue(7).ToString();
                    txtTitrateAmt.Text = reader.GetValue(8).ToString();
                    txtSeqLen.Text = reader.GetValue(9).ToString();
                    txtLane.Text = reader.GetValue(10).ToString();
                    txtIndexMID.Text = reader.GetValue(11).ToString();
                    strRunDate = reader.GetValue(12).ToString();
                    txtRunName.Text = reader.GetValue(13).ToString();
                    txtRef2Use.Text = reader.GetValue(14).ToString();
                }
                reader.Close();
                sqlConn.Close();

                string RTSPID = "";
                sqlString = "Select RTSPID FROM [tblProjSample] WHERE RTSSID = @strID";
                sqlComm = new SqlCommand(sqlString, sqlConn);
                sqlComm.Parameters.AddWithValue("@strID", RTSSID);
                sqlConn.Open();
                reader = sqlComm.ExecuteReader();

                while (reader.Read())
                {
                    RTSPID = reader.GetValue(0).ToString();
                }
                reader.Close();
                sqlConn.Close();

                hlSamples.NavigateUrl = "/Projects/ProjSamples.aspx?RTSPID=" + RTSPID;


                if ("" + NGSID == "")
                {
                    DataButton.Text = "Add Data";
                }
                else
                {
                    blnAdd = false;
                    DataButton.Text = "Edit Data";
                    hdnNGSID.Value = NGSID;
                }



                if (DateTime.TryParse(strLibDate, out dateTime2))
                {
                    libDate = dateTime2;
                }
                else
                {
                    libDate = DateTime.Today;
                }

                if (DateTime.TryParse(strRunDate, out dateTime2a))
                {
                    runDate = dateTime2a;
                }
                else
                {
                    runDate = DateTime.Today;
                }

                int libDay = (libDate.Day);
                int libMonth = (libDate.Month);
                int libYear = (libDate.Year);
                int runDay = (runDate.Day);
                int runMonth = (runDate.Month);
                int runYear = (runDate.Year);

                for (var i = 1; i < 13; i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlLibStartM.Items.Add(item);

                    if (i == libMonth)
                    {
                        ddlLibStartM.SelectedIndex = i;
                    }

                }
                for (var i = 1; i < 13; i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlRunStartM.Items.Add(item);

                    if (i == runMonth)
                    {
                        ddlRunStartM.SelectedIndex = i;
                    }
                }

                for (var i = 1; i < 32; i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlLibStartD.Items.Add(item);

                    if (i == libDay)
                    {
                        ddlLibStartD.SelectedIndex = i;
                    }
                }
                for (var i = 1; i < 32; i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlRunStartD.Items.Add(item);

                    if (i == runDay)
                    {
                        ddlRunStartD.SelectedIndex = i;
                    }
                }

                for (var i = libYear; i < (libYear + 3); i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlLibStartY.Items.Add(item);

                    if (i == libYear)
                    {
                        ddlLibStartY.SelectedIndex = ((libYear + 1) - libYear);
                    }
                }

                for (var i = runYear; i < (runYear + 3); i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlRunStartY.Items.Add(item);

                    if (i == runYear)
                    {
                        ddlRunStartY.SelectedIndex = ((runYear + 1) - runYear);
                    }
                }
            }
        }


        protected void DataButton_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {

                string NGSID = "";
                Object returnValue;
                string strID = "";
                string LibStart = ddlLibStartM.SelectedValue + "/" + ddlLibStartD.SelectedValue + "/" + ddlLibStartY.SelectedValue;
                string RunStart = ddlRunStartM.SelectedValue + "/" + ddlRunStartD.SelectedValue + "/" + ddlRunStartY.SelectedValue;

                if (hdnNGSID.Value != "")
                {
                    NGSID = hdnNGSID.Value;
                    blnAdd = false;
                }
                else
                {
                    blnAdd = true;
                }

                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
                SqlCommand cmd = conn.CreateCommand();

                if (blnAdd)
                {
                    cmd.CommandText = "sproc_AddNGSData";
                }
                else
                {
                    cmd.CommandText = "sproc_EditNGSData";
                    cmd.Parameters.AddWithValue("@NGSID", NGSID);
                }

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RTSSID", RTSSID);
                cmd.Parameters.AddWithValue("@Instrument", ddlInstrument.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@InvSample", txtInvSample.Text);
                cmd.Parameters.AddWithValue("@LibDate", LibStart);
                cmd.Parameters.AddWithValue("@PrepBy", txtPrepBy.Text);
                cmd.Parameters.AddWithValue("@LibType", txtLibType.Text);
                cmd.Parameters.AddWithValue("@SizeRange", txtSizeRange.Text);
                cmd.Parameters.AddWithValue("@AvgSize", txtAvgSize.Text);
                cmd.Parameters.AddWithValue("@TitrateAmt", txtTitrateAmt.Text);
                cmd.Parameters.AddWithValue("@SeqLen", txtSeqLen.Text);
                cmd.Parameters.AddWithValue("@Lane", txtLane.Text);
                cmd.Parameters.AddWithValue("@IndexMID", txtIndexMID.Text);
                cmd.Parameters.AddWithValue("@RunDate", RunStart);
                cmd.Parameters.AddWithValue("@RunName", txtRunName.Text);
                cmd.Parameters.AddWithValue("@Ref2Use", txtRef2Use.Text);
                cmd.Parameters.AddWithValue("@EnteredBy", grpMember);
                cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);

                conn.Open();
                if (blnAdd)
                {
                    returnValue = cmd.ExecuteScalar();
                    strID = returnValue.ToString();  //Not used at this point
                }
                else
                {
                    cmd.ExecuteNonQuery();
                }

                cmd.Dispose();
                conn.Dispose();

            }

            string RTSPID = "";
            string connString = ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString;
            string sqlString = "Select RTSPID FROM [tblProjSample] WHERE RTSSID = @strID";
            SqlConnection sqlConn = new SqlConnection(connString);
            SqlCommand sqlComm = new SqlCommand(sqlString, sqlConn);
            sqlComm.Parameters.AddWithValue("@strID", RTSSID);
            sqlConn.Open();
            SqlDataReader reader = sqlComm.ExecuteReader();

            while (reader.Read())
            {
                RTSPID = reader.GetValue(0).ToString();
            }
            reader.Close();
            sqlConn.Close();

            Response.Redirect("/Projects/ProjSamples.aspx?RTSPID=" + RTSPID);
        }
    }
}
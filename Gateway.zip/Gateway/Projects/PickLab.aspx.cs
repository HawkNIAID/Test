﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Gateway.Projects
{
    public partial class PickLab : System.Web.UI.Page
    {
        public string RTSSID { get; set; }
        public string grpMember { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            RTSSID = HttpUtility.UrlDecode(Request.QueryString["RTSSID"]);
            grpMember = System.Web.HttpContext.Current.Session["NIHID"].ToString();
            string groupnum = "0";
            //string Abrv = "";

            //Get the associated Lab from the logged in Group Member
            string connString = ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString;
            string sqlString = "Select grpID FROM tblGroupMember WHERE NIHID = @strID";
            SqlConnection sqlConn = new SqlConnection(connString);
            SqlCommand sqlComm = new SqlCommand(sqlString, sqlConn);
            sqlComm.Parameters.AddWithValue("@strID", grpMember);
            sqlConn.Open();
            SqlDataReader reader = sqlComm.ExecuteReader();

            while (reader.Read())
            {
                groupnum = reader.GetValue(0).ToString();
            }
            reader.Close();
            sqlConn.Close();


            switch (groupnum)
            {
                case "1":
                    Response.Redirect("/Lab/dataNGS.aspx?RTSSID=" + RTSSID);
                    break;
                case "2":
                    Response.Redirect("/Lab/dataMA.aspx?RTSSID=" + RTSSID);
                    break;
                case "3":
                    Response.Redirect("/Lab/dataSAMP.aspx?RTSSID=" + RTSSID);
                    break;
                case "4":
                    Response.Redirect("/Lab/dataBIO.aspx?RTSSID=" + RTSSID);
                    break;
                case "5":
                    Response.Redirect("/Lab/dataADMIN.aspx?RTSSID=" + RTSSID);
                    break;

                default:
                    Response.Redirect("/Lab/dataNA.aspx?RTSSID=" + RTSSID);
                    break;
            }
        }
    }
}
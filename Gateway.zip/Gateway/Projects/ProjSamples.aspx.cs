﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClosedXML.Excel;

namespace Gateway.Projects
{
    public partial class ProjSamples : System.Web.UI.Page
    {
        public string RTSPID { get; set; }
        public string grpMember { get; set; }
        List<string> Abrvs { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            RTSPID = HttpUtility.UrlDecode(Request.QueryString["RTSPID"]);
            HiddenField1.Value = RTSPID.ToString().Trim();
            grpMember = System.Web.HttpContext.Current.Session["NIHID"].ToString();
            lnkAddSample.NavigateUrl = "/Samples/AddSample.aspx?RTSPID=" + RTSPID;
            lnkGrpUpdate.NavigateUrl = "/Samples/GrpUpdate.aspx?RTSPID=" + RTSPID;
            Abrvs = (List<string>)Session["myAbrvs"];

            string connString = ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString;
            //string sqlString = "SELECT TOP 1 tblProject.Name, tblDataNGS.UpdatedOn, tblGroupMember.nameFirst FROM tblDataNGS INNER JOIN tblProjSample ON tblDataNGS.RTSSID = tblProjSample.RTSSID INNER JOIN tblProject ON tblProjSample.RTSPID = tblProject.RTSPID LEFT OUTER JOIN tblGroupMember ON tblDataNGS.UpdatedBy = tblGroupMember.NIHID WHERE (tblProjSample.RTSPID = @strID) ORDER BY UpdatedOn DESC";
            string sqlString = "SELECT TOP 1 tblProject.Name FROM tblProjSample INNER JOIN tblProject ON tblProjSample.RTSPID = tblProject.RTSPID WHERE (tblProjSample.RTSPID = @strID)";
            SqlConnection sqlConn = new SqlConnection(connString);
            SqlCommand sqlComm = new SqlCommand(sqlString, sqlConn);
            sqlComm.Parameters.AddWithValue("@strID", RTSPID);
            sqlConn.Open();
            SqlDataReader reader = sqlComm.ExecuteReader();

            while (reader.Read())
            {
                Label1.Text = reader.GetValue(0).ToString();
                //Label3.Text = "Last updated on " + reader.GetValue(1).ToString() + " by " + reader.GetValue(2).ToString();
            }
            reader.Close();
            sqlConn.Close();
        }


        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //e.Row.Cells[3].Text += " (" + Session["group"] + ")";

                string Abrv = DataBinder.Eval(e.Row.DataItem, "Abrv").ToString();
                if (!Abrvs.Contains(Abrv, StringComparer.OrdinalIgnoreCase) && Abrv != "")
                {
                    //LinkButton lb = (LinkButton)e.Row.Cells[0].Controls[0];
                    //lb.Text = "View";
                }
            }
        }


        protected void Grid_SelectedIndexChanged(object sender, EventArgs e)
        {
            LinkButton lb = (LinkButton)GridView1.SelectedRow.Cells[0].Controls[0];
            string RTSSID = GridView1.SelectedRow.Cells[1].Text.Trim();
            //Label2.Text = lb.Text;

            if (lb.Text == "Edit")
            {
                Response.Redirect("/Samples/EditSample.aspx?RTSSID=" + RTSSID);
            }
            else
            {
                Response.Redirect("/Samples/ViewSample.aspx?RTSSID=" + RTSSID);
            }
        }
        

        protected void btnGetData_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            DataTable dt2 = new DataTable();
            DataTable dt3 = new DataTable();
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
            //SqlDataAdapter da = new SqlDataAdapter("SELECT [RTSPID],[Name],[Investigator],[Lab],[Phone],[tblProject].[Email],[Organism],[Host],[sampleSource],[numSamples],[Summary],[Analysis],[EnteredOn], tblGroupMember.NIHID AS EnteredBy FROM [RTS].[dbo].[tblProject] LEFT OUTER JOIN tblGroupMember ON tblProject.EnteredBy = tblGroupMember.gmID WHERE (tblProject.RTSPID = @strID)", conn);
            //da.SelectCommand.Parameters.Add(new SqlParameter("@strID", RTSPID));
            SqlDataAdapter da2 = new SqlDataAdapter("SELECT [RTSPID],[RTSSID],[Name],[Notes],[recDate],[recBy],[EnteredOn],[Status], tblGroupMember.NIHID AS AssignedTo FROM [RTS].[dbo].[tblProjSample] LEFT OUTER JOIN tblGroupMember ON tblProjSample.AssignedTo = tblGroupMember.gmID WHERE (RTSPID = @strID)", conn);
            da2.SelectCommand.Parameters.Add(new SqlParameter("@strID", RTSPID));
            //SqlDataAdapter da3 = new SqlDataAdapter("SELECT tblDataNGS.RTSSID, tblDataNGS.NGSID, tblDataNGS.Instrument, tblDataNGS.InvestigatorSample, tblDataNGS.LibStartDate, tblDataNGS.PreppedBy, tblDataNGS.LibType, tblDataNGS.SizeRange, tblDataNGS.AvgSize, tblDataNGS.TitrationAmt, tblDataNGS.SeqLength, tblDataNGS.Lane, tblDataNGS.IndexMID, tblDataNGS.RunStartDate, tblDataNGS.RunName, tblDataNGS.RefToUse FROM tblDataNGS INNER JOIN tblProjSample ON tblDataNGS.RTSSID = tblProjSample.RTSSID WHERE (tblProjSample.RTSPID = @strID)", conn);
            //da3.SelectCommand.Parameters.Add(new SqlParameter("@strID", RTSPID));
            conn.Open();
            //da.Fill(dt);
            da2.Fill(dt2);
            //da3.Fill(dt3);
            conn.Close();

            XLWorkbook wb = new XLWorkbook();
            //IXLWorksheet ws = wb.Worksheets.Add(dt, "Project");
            //ws.SheetView.FreezeRows(1);
            IXLWorksheet ws2 = wb.Worksheets.Add(dt2, "Samples");
            ws2.SheetView.FreezeRows(1);
            //IXLWorksheet ws3 = wb.Worksheets.Add(dt3, "Lab_Data");
            //ws3.SheetView.FreezeRows(1);
            
            //Lock the columns we don't want people to play with - EDIT: This ain't working...
            //wb.Worksheet(1).Range(startRow, startColumn, endRow, endColumn).Style.Protection.SetLocked(true);
            //ws.Range(1, 1, 1, 18).Style.Protection.SetLocked(true); //whole first row = column names
            //ws.Range(2, 1, 999, 1).Style.Protection.SetLocked(true); //first column
            //ws.Range(2, 2, 999, 2).Style.Protection.SetLocked(true); //second column
            //ws.Range(2, 3, 999, 3).Style.Protection.SetLocked(true); //third column
            //ws.Range(2, 18, 999, 18).Style.Protection.SetLocked(true); //18th column

            // Prepare the response
            HttpResponse httpResponse = Response;
            httpResponse.Clear();
            httpResponse.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            httpResponse.AddHeader("content-disposition", "attachment;filename=\"Datasheet.xlsx\"");

            // Flush the workbook to the Response.OutputStream
            using (MemoryStream memoryStream = new MemoryStream())
            {
                wb.SaveAs(memoryStream);
                memoryStream.WriteTo(httpResponse.OutputStream);
                memoryStream.Close();
            }

            httpResponse.End();
        }



        protected void ImportExcel(object sender, EventArgs e)
        {
            if ((FileUpload1.PostedFile != null) && (FileUpload1.PostedFile.ContentLength > 0))
            {
                //Save the uploaded Excel file.
                string filePath = Server.MapPath("~/Files/") + Path.GetFileName(FileUpload1.PostedFile.FileName);
                FileUpload1.SaveAs(filePath);
                //string fn = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
                //StreamReader oStreamReader = new StreamReader(FileUpload1.PostedFile.InputStream);

                //TEST read to memory
                //string content;
                //using (StreamReader oStreamReader = new StreamReader(FileUpload1.PostedFile.InputStream, Encoding.Unicode))
                //{
                    //content = oStreamReader.ReadToEnd();

                    //Open the Excel file using ClosedXML.
                    using (XLWorkbook workBook = new XLWorkbook(filePath))
                    {
                        //Read the third Sheet from Excel file.
                        IXLWorksheet workSheet = workBook.Worksheet(3);

                        //Create a new DataTable.
                        DataTable dt = new DataTable();

                        //Loop through the Worksheet rows.
                        bool firstRow = true;
                        int intRow = 0;
                        int intCells = 0;
                        foreach (IXLRow row in workSheet.Rows())
                        {
                            //Use the first row to add columns to DataTable.
                            if (firstRow)
                            {
                                foreach (IXLCell cell in row.Cells())
                                {
                                    dt.Columns.Add(cell.Value.ToString());
                                    intCells++;
                                }
                                firstRow = false;
                            }
                            else
                            {
                                //Add rows to DataTable.
                                //int i = 0;
                                //foreach (IXLCell cell in row.Cells())
                                dt.Rows.Add();
                                for (int i = 0; i < intCells; i++)
                                {
                                    dt.Rows[dt.Rows.Count - 1][i] = workSheet.Cell(intRow + 1, i + 1).Value.ToString();
                                    //i++;
                                }
                            }
                            intRow++;
                        }

                        showcells.DataSource = dt;
                        showcells.DataBind();
                        Commit.Visible = true;
                    }
                //}

                System.IO.File.Delete(filePath);  //Delete the file after loaded in memory
            }
        }


        protected void Commit_ServerClick(object sender, System.EventArgs e)
        {
            if (Page.IsValid)
            {
                int i = 0;
                Object returnValue;
                string strID = "";

                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();


                int numRTSSID;
                int numNGSID;
                foreach (GridViewRow row in showcells.Rows)
                {
                    if (int.TryParse(row.Cells[0].Text, out numRTSSID))  //Make sure we have a valid RTSSID
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@RTSSID", numRTSSID);
                        cmd.Parameters.AddWithValue("@Instrument", trim(row.Cells[2].Text, 5));
                        cmd.Parameters.AddWithValue("@InvSample", trim(row.Cells[3].Text, 50));
                        cmd.Parameters.AddWithValue("@LibDate", trim(row.Cells[4].Text, 25));
                        cmd.Parameters.AddWithValue("@PrepBy", trim(row.Cells[5].Text, 10));
                        cmd.Parameters.AddWithValue("@LibType", trim(row.Cells[6].Text, 50));
                        cmd.Parameters.AddWithValue("@SizeRange", trim(row.Cells[7].Text, 20));
                        cmd.Parameters.AddWithValue("@AvgSize", trim(row.Cells[8].Text, 10));
                        cmd.Parameters.AddWithValue("@TitrateAmt", trim(row.Cells[9].Text, 50));
                        cmd.Parameters.AddWithValue("@SeqLen", trim(row.Cells[10].Text, 20));
                        cmd.Parameters.AddWithValue("@Lane", trim(row.Cells[11].Text, 20));
                        cmd.Parameters.AddWithValue("@IndexMID", trim(row.Cells[12].Text, 75));
                        cmd.Parameters.AddWithValue("@RunDate", trim(row.Cells[13].Text, 25));
                        cmd.Parameters.AddWithValue("@RunName", trim(row.Cells[14].Text, 75));
                        cmd.Parameters.AddWithValue("@Ref2Use", trim(row.Cells[15].Text, 50));
                        cmd.Parameters.AddWithValue("@EnteredBy", grpMember);

                        if (int.TryParse(row.Cells[1].Text, out numNGSID))  //Update existing record if there is one
                        {
                            cmd.CommandText = "sproc_EditNGSData";
                            cmd.Parameters.AddWithValue("@NGSID", numNGSID);
                            cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                            cmd.ExecuteNonQuery();
                        }
                        else   //Add a new record
                        {
                            cmd.CommandText = "sproc_AddNGSData";
                            returnValue = cmd.ExecuteScalar();
                            strID = returnValue.ToString();  //Not used at this point
                        }

                        cmd.Parameters.Clear();
                        i++;
                    }
                }


                cmd.Dispose();
                conn.Dispose();
                Response.Redirect("/Projects/ProjSamples.aspx?RTSPID=" + RTSPID);  //Reloads the page
            }
        }


        //Function takes string and length. If string is longer, it gets trimmed.
        static public string trim(string x, int y)
        {
            x = x.Replace("&nbsp;", "");
            if (x.Length > y)
            {
                return x.Substring(0, y);
            }
            else
            {
                return x;
            }
        }
    }
}
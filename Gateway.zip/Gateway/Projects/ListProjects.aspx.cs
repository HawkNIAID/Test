﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Gateway.Projects
{
    public partial class ListProjects : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void Grid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strID = GridView1.SelectedDataKey.Value.ToString();
            Response.Redirect("EditProject.aspx?RTSPID=" + strID);
        }


        //protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        e.Row.Cells[4].Text += " (" + Session["group"] + ")";
        //    }
        //}
    }
}
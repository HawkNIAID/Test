﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections; // this enables ArrayList
using System.Data.SqlClient; // this enables SqlConnection and SqlCommand
using System.Data; // this enables CommandType
using System.Configuration; // this enables ConfigurationManager
using System.Text; // this enables StringBuilder

namespace Gateway.Projects
{
    public partial class EditProject : System.Web.UI.Page
    {
        public string RTSPID { get; set; }
        public string grpMember { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            RTSPID = HttpUtility.UrlDecode(Request.QueryString["RTSPID"]);
            grpMember = System.Web.HttpContext.Current.Session["NIHID"].ToString();

            if (!IsPostBack)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
                string sqlString = "SELECT Name, Investigator, Phone, Email, Lab, Organism, Host, sampleSource, numSamples, Summary, Analysis, Status FROM tblProject WHERE RTSPID = @ID";
                SqlCommand sqlComm = new SqlCommand(sqlString, conn);
                sqlComm.Parameters.Add(new SqlParameter("@ID", RTSPID));
                conn.Open();
                SqlDataReader reader = sqlComm.ExecuteReader();

                if (reader.HasRows)
                {
                    reader.Read();
                    {
                        txtProjectName.Text = reader.GetValue(0).ToString();
                        txtInvestigator.Text = reader.GetValue(1).ToString();
                        txtPhone.Text = reader.GetValue(2).ToString();
                        txtEmail.Text = reader.GetValue(3).ToString();
                        txtLab.Text = reader.GetValue(4).ToString();
                        txtOrganism.Text = reader.GetValue(5).ToString();
                        txtHost.Text = reader.GetValue(6).ToString();
                        txtSource.Text = reader.GetValue(7).ToString();
                        txtSamples.Text = reader.GetValue(8).ToString();
                        txtSummary.Text = reader.GetValue(9).ToString();
                        txtAnalysis.Text = reader.GetValue(10).ToString();
                        ddlStatus.SelectedValue = reader.GetValue(11).ToString().Trim();
                    }
                }
                conn.Close();
                
            }
        }


        protected void EditButton_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
                SqlCommand cmd = conn.CreateCommand();

                cmd.CommandText = "sproc_EditProject";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@RTSPID", RTSPID);
                cmd.Parameters.AddWithValue("@Name", txtProjectName.Text);
                cmd.Parameters.AddWithValue("@Investigator", txtInvestigator.Text);
                cmd.Parameters.AddWithValue("@Lab", txtLab.Text);
                cmd.Parameters.AddWithValue("@Phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@Organism", txtOrganism.Text);
                cmd.Parameters.AddWithValue("@Host", txtHost.Text);
                cmd.Parameters.AddWithValue("@sampleSource", txtSource.Text);
                cmd.Parameters.AddWithValue("@numSamples", txtSamples.Text);
                cmd.Parameters.AddWithValue("@Summary ", txtSummary.Text);
                cmd.Parameters.AddWithValue("@Analysis", txtAnalysis.Text);
                cmd.Parameters.AddWithValue("@recBy", Session["gmID"].ToString());
                cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
                cmd.Parameters.Add("@scopeID", SqlDbType.Int, 0, "scopeID");
                cmd.Parameters["@scopeID"].Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();

                cmd.Dispose();
                conn.Dispose();

                Response.Redirect("ListProjects.aspx");
            }

        }
    }
}
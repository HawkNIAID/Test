﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient; // this enables SqlConnection and SqlCommand
using System.Data; // this enables CommandType
using System.Configuration; // this enables ConfigurationManager

namespace Gateway
{
    public partial class SiteMaster : MasterPage
    {
        private const string AntiXsrfTokenKey = "__AntiXsrfToken";
        private const string AntiXsrfUserNameKey = "__AntiXsrfUserName";
        private string _antiXsrfTokenValue;

        protected void Page_Init(object sender, EventArgs e)
        {
            // The code below helps to protect against XSRF attacks
            var requestCookie = Request.Cookies[AntiXsrfTokenKey];
            Guid requestCookieGuidValue;
            if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
            {
                // Use the Anti-XSRF token from the cookie
                _antiXsrfTokenValue = requestCookie.Value;
                Page.ViewStateUserKey = _antiXsrfTokenValue;
            }
            else
            {
                // Generate a new Anti-XSRF token and save to the cookie
                _antiXsrfTokenValue = Guid.NewGuid().ToString("N");
                Page.ViewStateUserKey = _antiXsrfTokenValue;

                var responseCookie = new HttpCookie(AntiXsrfTokenKey)
                {
                    HttpOnly = true,
                    Value = _antiXsrfTokenValue
                };
                if (FormsAuthentication.RequireSSL && Request.IsSecureConnection)
                {
                    responseCookie.Secure = true;
                }
                Response.Cookies.Set(responseCookie);
            }


            //* Custom code for Gateway *//

            bool blnValid = false;
            hdnID.Value = System.Web.HttpContext.Current.Session["NIHID"].ToString();
            //hdnID.Value = "brunoda";
            String thisURL = Path.GetFileNameWithoutExtension(Page.AppRelativeVirtualPath);
            //string gmID = "";
            //string group = "";
            List<string> myAbrvs = new List<string>();
            myAbrvs = (List<string>)Session["myAbrvs"];


            //Check session and redirect if not in RTS
            if (!string.IsNullOrEmpty(System.Web.HttpContext.Current.Session["NIHID"].ToString()))
            {
                string connString = ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString;
                string sqlString = "SELECT NIHID FROM tblGroupMember WHERE Inactive = 'False' AND NIHID = @strID";
                //string sqlString = "SELECT tblGroupMember.nameFirst, tblGroup.Abrv, tblGroupMember.gmID FROM tblGroupMember INNER JOIN tblGroup ON tblGroupMember.grpID = tblGroup.grpID WHERE NIHID = @strID";
                SqlConnection sqlConn = new SqlConnection(connString);
                SqlCommand sqlComm = new SqlCommand(sqlString, sqlConn);
                sqlComm.Parameters.AddWithValue("@strID", hdnID.Value);
                sqlConn.Open();
                SqlDataReader reader = sqlComm.ExecuteReader();
                if (reader.HasRows)
                {
                    //reader.Read();
                    //{
                        //Mark as Valid and create label and links
                        blnValid = true;

                        Label1.Text = Session["myName"].ToString();
                        Label1.Text += " (" + Session["group"].ToString() + ")";
                        Link1.Text = Session["myName"].ToString();
                        Link1.Text += " (" + Session["group"].ToString() + ")";
                        
                    //    group = reader.GetValue(1).ToString();
                    //    gmID = reader.GetValue(2).ToString();
                    //}
                }
                reader.Close();
                sqlConn.Close();


                //sqlString = "SELECT tblGroup.Abrv FROM tblGroupMember INNER JOIN tblGroup ON tblGroupMember.grpID = tblGroup.grpID WHERE (tblGroupMember.NIHID = @strID)";
                //sqlComm = new SqlCommand(sqlString, sqlConn);
                //sqlComm.Parameters.AddWithValue("@strID", hdnID.Value);
                //sqlConn.Open();
                //reader = sqlComm.ExecuteReader();
                //if (reader.HasRows)
                //{
                //    while (reader.Read())
                //    {
                //        myAbrvs.Add(reader.GetValue(0).ToString());
                //    }
                //}
                //reader.Close();
                //sqlConn.Close();

                //If a member of multiple, hide label and show link
                if (myAbrvs.Count > 1)
                {
                    Link1.Visible = true;
                    Label1.Visible = false;
                }
            }

            //blnValid = false;     //for testing
            hdnValid.Value = blnValid.ToString();
            hdnGroup.Value = Session["group"].ToString();

            if (thisURL != "Denied")
            {
                if (!blnValid)
                {
                    Response.Redirect("~/Denied.aspx", false);
                }
            }

            //Set Session variables
            //if (Session["gmID"] == null)
            //{
            //    Session["gmID"] = gmID;
            //}

            //if (Session["group"] == null)
            //{
            //    Session["group"] = group;
            //}

            //if (Session["myAbrvs"] == null)
            //{
            //    Session["myAbrvs"] = myAbrvs;
            //}
            //* END custom code for Gateway *//


            Page.PreLoad += master_Page_PreLoad;
        }

        protected void master_Page_PreLoad(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Set Anti-XSRF token
                ViewState[AntiXsrfTokenKey] = Page.ViewStateUserKey;
                ViewState[AntiXsrfUserNameKey] = Context.User.Identity.Name ?? String.Empty;
            }
            else
            {
                // Validate the Anti-XSRF token
                if ((string)ViewState[AntiXsrfTokenKey] != _antiXsrfTokenValue
                    || (string)ViewState[AntiXsrfUserNameKey] != (Context.User.Identity.Name ?? String.Empty))
                {
                    throw new InvalidOperationException("Validation of Anti-XSRF token failed.");
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections; // this enables ArrayList
using System.Data.SqlClient; // this enables SqlConnection and SqlCommand
using System.Data; // this enables CommandType
using System.Configuration; // this enables ConfigurationManager
using System.Text; // this enables StringBuilder

namespace Gateway.Samples
{
    public partial class ViewSample : System.Web.UI.Page
    {
        public string RTSSID { get; set; }
        public string grpMember { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            RTSSID = HttpUtility.UrlDecode(Request.QueryString["RTSSID"]);
            grpMember = System.Web.HttpContext.Current.Session["NIHID"].ToString();

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
            string sqlString = "SELECT tblProjSample.Name, tblProjSample.Notes, tblProjSample.recDate, tblProjSample.AssignedTo, tblProject.Name AS Expr1, tblGroupMember.nameFirst, tblGroup.Abrv, tblProjSample.Status FROM tblGroup INNER JOIN tblGroupMember ON tblGroup.grpID = tblGroupMember.grpID RIGHT OUTER JOIN tblProjSample INNER JOIN tblProject ON tblProjSample.RTSPID = tblProject.RTSPID ON tblGroupMember.gmID = tblProjSample.AssignedTo WHERE (tblProjSample.RTSSID = @ID)";
            SqlCommand sqlComm = new SqlCommand(sqlString, conn);
            sqlComm.Parameters.Add(new SqlParameter("@ID", RTSSID));
            conn.Open();

            SqlDataReader reader = sqlComm.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                {
                    lblSampleName.Text = reader.GetValue(0).ToString();
                    lblNotes.Text = reader.GetValue(1).ToString();
                    lblDate.Text = DateTime.Parse(reader.GetValue(2).ToString()).ToShortDateString();
                    lblProject.Text = reader.GetValue(4).ToString();
                    lblAssignedTo.Text = reader.GetValue(5).ToString() + " (" + reader.GetValue(6).ToString() + ")";
                    lblStatus.Text = reader.GetValue(7).ToString();
                }
            }

            reader.Dispose();
            sqlComm.Dispose();
            conn.Close();

        }
    }
}
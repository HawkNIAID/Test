﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ClosedXML.Excel;

namespace Gateway.Samples
{
    public partial class AddSampleBatch : System.Web.UI.Page
    {
        public DataTable oDataTable = null;
        public string RTSPID { get; set; }
        public string grpMember { get; set; }
        public string rowcount { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            RTSPID = HttpUtility.UrlDecode(Request.QueryString["RTSPID"]);
            grpMember = System.Web.HttpContext.Current.Session["NIHID"].ToString();

            if (!IsPostBack)
            {
                ddlProject.AppendDataBoundItems = true;
                string sqlString = "Select [Name], RTSPID FROM tblProject ORDER BY Name";
                string connString = ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString;
                SqlConnection sqlConn = new SqlConnection(connString);
                SqlCommand sqlComm = new SqlCommand(sqlString, sqlConn);

                try
                {
                    sqlConn.Open();
                    ddlProject.DataSource = sqlComm.ExecuteReader();
                    ddlProject.DataTextField = "Name";
                    ddlProject.DataValueField = "RTSPID";
                    ddlProject.DataBind();
                    ddlProject.SelectedValue = RTSPID;
                }

                finally
                {
                    sqlConn.Close();
                    sqlConn.Dispose();
                }


                int intDay = (DateTime.Now.Day);
                int intMonth = (DateTime.Now.Month);
                int intYear = (DateTime.Now.Year);

                for (var i = 1; i < 13; i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlDeliveredM.Items.Add(item);

                    if (i == intMonth)
                    {
                        ddlDeliveredM.SelectedIndex = i;
                    }
                }

                for (var i = 1; i < 32; i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlDeliveredD.Items.Add(item);

                    if (i == intDay)
                    {
                        ddlDeliveredD.SelectedIndex = i;
                    }
                }

                for (var i = intYear; i < (intYear + 3); i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlDeliveredY.Items.Add(item);

                    if (i == intYear)
                    {
                        ddlDeliveredY.SelectedIndex = ((intYear + 1) - intYear);
                    }
                }
            }
        }


        protected void Submit1_ServerClick(object sender, System.EventArgs e)
        {
            if ((FileUpload1.PostedFile != null) && (FileUpload1.PostedFile.ContentLength > 0))
            {
                //Save the uploaded Excel file.
                string filePath = Server.MapPath("~/Files/") + Path.GetFileName(FileUpload1.PostedFile.FileName);
                FileUpload1.SaveAs(filePath);

                //Open the Excel file using ClosedXML.
                using (XLWorkbook workBook = new XLWorkbook(filePath))
                {
                    //Read the first Sheet from Excel file.
                    IXLWorksheet workSheet = workBook.Worksheet(1);

                    //Create a new DataTable.
                    DataTable dt = new DataTable();

                    //Loop through the Worksheet rows.
                    bool firstRow = true;
                    int intRow = 0;
                    int intCells = 0;
                    foreach (IXLRow row in workSheet.Rows())
                    {
                        //Use the first row to add columns to DataTable.
                        if (firstRow)
                        {
                            foreach (IXLCell cell in row.Cells())
                            {
                                dt.Columns.Add(cell.Value.ToString());
                                intCells++;
                            }
                            firstRow = false;
                        }
                        else
                        {
                            //Add rows to DataTable.
                            dt.Rows.Add();
                            for (int i = 0; i < intCells; i++)
                            {
                                dt.Rows[dt.Rows.Count - 1][i] = workSheet.Cell(intRow + 1, i + 1).Value.ToString();
                            }
                        }
                        intRow++;
                    }

                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    Commit.Visible = true;
                }

                System.IO.File.Delete(filePath);  //Delete the file after loaded in memory
            }
            else
            {
                Label1.Text = "Please select a file to upload.";
            }
        }

        
        protected void Commit_ServerClick(object sender, System.EventArgs e)
        {
            if (Page.IsValid)
            {
                int i = 0;
                string Received = ddlDeliveredM.SelectedValue + "/" + ddlDeliveredD.SelectedValue + "/" + ddlDeliveredY.SelectedValue;
                string strProj = ddlProject.SelectedItem.Value;
                string strTimeName = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");
                Object returnValue;

                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();

                if (strProj == "0") //User selected NEW, so we add a NEW Project with DateTime as Name
                {
                    cmd.CommandText = "sproc_AddProject";
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Name", strTimeName);
                    cmd.Parameters.AddWithValue("@Investigator", "");
                    cmd.Parameters.AddWithValue("@Lab", "");
                    cmd.Parameters.AddWithValue("@Phone", "");
                    cmd.Parameters.AddWithValue("@Email", "");
                    cmd.Parameters.AddWithValue("@Organism", "");
                    cmd.Parameters.AddWithValue("@Host", "");
                    cmd.Parameters.AddWithValue("@sampleSource", "");
                    cmd.Parameters.AddWithValue("@numSamples", hdnRowCount.Value);
                    cmd.Parameters.AddWithValue("@Summary ", "");
                    cmd.Parameters.AddWithValue("@Analysis", "");
                    cmd.Parameters.AddWithValue("@EnteredBy", System.Web.HttpContext.Current.Session["gmID"].ToString()); 
                    cmd.Parameters.AddWithValue("@Status", "Received");

                    returnValue = cmd.ExecuteScalar();
                    cmd.Parameters.Clear();
                    strProj = returnValue.ToString();
                }
                

                cmd.CommandText = "sproc_AddSample";
                cmd.CommandType = CommandType.StoredProcedure;

                foreach (GridViewRow row in GridView1.Rows)
                {
                    cmd.Parameters.AddWithValue("@RTSPID", strProj);
                    cmd.Parameters.AddWithValue("@Name", trim(row.Cells[0].Text, 50));
                    cmd.Parameters.AddWithValue("@Notes", txtNotes.Text);
                    cmd.Parameters.AddWithValue("@recDate", Received);
                    cmd.Parameters.AddWithValue("@recBy", grpMember);
                    cmd.Parameters.AddWithValue("@AssignedTo", System.Web.HttpContext.Current.Session["gmID"].ToString()); 
                    cmd.Parameters.AddWithValue("@Status", "Received");

                    cmd.ExecuteScalar();
                    cmd.Parameters.Clear();
                    i++;
                }

                cmd.Dispose();
                conn.Dispose();
                Response.Redirect("/Projects/Index.aspx");
            }
        }


        //Function takes string and length. If string is longer, it gets trimmed.
        static public string trim(string x, int y)
        {
            if (x.Length > y)
            {
                return x.Substring(0, y);
            }
            else
            {
                return x;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections; // this enables ArrayList
using System.Data.SqlClient; // this enables SqlConnection and SqlCommand
using System.Data; // this enables CommandType
using System.Configuration; // this enables ConfigurationManager
using System.Text; // this enables StringBuilder

namespace Gateway.Samples
{
    public partial class EditSample : System.Web.UI.Page
    {
        public string RTSSID { get; set; }
        public DateTime thisDate { get; set; }
        public string grpMember { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            RTSSID = HttpUtility.UrlDecode(Request.QueryString["RTSSID"]);
            grpMember = System.Web.HttpContext.Current.Session["NIHID"].ToString();
            string RTSPID = "0";
            string Assignment = "";
            
            if (!IsPostBack)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
                string sqlString = "SELECT RTSPID, Name, Notes, recDate, AssignedTo, Status FROM tblProjSample WHERE RTSSID = @ID";
                SqlCommand sqlComm = new SqlCommand(sqlString, conn);
                sqlComm.Parameters.Add(new SqlParameter("@ID", RTSSID));
                conn.Open();

                SqlDataReader reader = sqlComm.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    {
                        RTSPID = reader.GetValue(0).ToString();
                        txtSampleName.Text = reader.GetValue(1).ToString();
                        txtNotes.Text = reader.GetValue(2).ToString();
                        thisDate = Convert.ToDateTime(reader.GetValue(3).ToString());
                        Assignment = reader.GetValue(4).ToString();
                        ddlStatus.SelectedValue = reader.GetValue(5).ToString().Trim();
                    }
                }
                reader.Dispose();


                ddlAssignment.AppendDataBoundItems = true;
                sqlString = "SELECT tblGroupMember.gmID, tblGroupMember.nameFirst + ' (' + tblGroup.Abrv + ')' AS AbvName FROM tblGroupMember INNER JOIN tblGroup ON tblGroupMember.grpID = tblGroup.grpID WHERE Inactive = 'False' ORDER BY AbvName";
                sqlComm = new SqlCommand(sqlString, conn);
                //if (reader.HasRows)
                //{
                    //reader.Read();
                    //{
                        ddlAssignment.DataSource = sqlComm.ExecuteReader();
                        ddlAssignment.DataTextField = "AbvName";
                        ddlAssignment.DataValueField = "gmID";
                        ddlAssignment.DataBind();
                        ddlAssignment.SelectedValue = Assignment;
                    //}
                //}
                reader.Dispose();
                sqlComm.Dispose();
                conn.Close();


                ddlProject.AppendDataBoundItems = true;
                sqlString = "Select [Name], RTSPID FROM tblProject ORDER BY Name";
                conn.Open();
                sqlComm = new SqlCommand(sqlString, conn);
                try
                {
                    ddlProject.DataSource = sqlComm.ExecuteReader();
                    ddlProject.DataTextField = "Name";
                    ddlProject.DataValueField = "RTSPID";
                    ddlProject.DataBind();
                    ddlProject.SelectedValue = RTSPID;
                }
                finally
                {
                    conn.Close();
                }

                
                int intDay = (thisDate.Day);
                int intMonth = (thisDate.Month);
                int intYear = (thisDate.Year);

                for (var i = 1; i < 13; i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlDeliveredM.Items.Add(item);

                    if (i == intMonth)
                    {
                        ddlDeliveredM.SelectedIndex = i;
                    }
                }

                for (var i = 1; i < 32; i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlDeliveredD.Items.Add(item);

                    if (i == intDay)
                    {
                        ddlDeliveredD.SelectedIndex = i;
                    }
                }

                for (var i = intYear; i < (intYear + 3); i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlDeliveredY.Items.Add(item);

                    if (i == intYear)
                    {
                        ddlDeliveredY.SelectedIndex = ((intYear + 1) - intYear);
                    }
                }
            }
        }


        protected void EditButton_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                string Received = ddlDeliveredM.SelectedValue + "/" + ddlDeliveredD.SelectedValue + "/" + ddlDeliveredY.SelectedValue;

                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
                SqlCommand cmd = conn.CreateCommand();

                cmd.CommandText = "sproc_EditSample";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@RTSSID", RTSSID);
                cmd.Parameters.AddWithValue("@RTSPID", ddlProject.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@Name", txtSampleName.Text);
                cmd.Parameters.AddWithValue("@Notes", txtNotes.Text);
                cmd.Parameters.AddWithValue("@recDate", Received);
                cmd.Parameters.AddWithValue("@recBy", grpMember);
                if (ddlAssignment.SelectedItem.Value != "")  //DropDown was selected
                {
                    cmd.Parameters.AddWithValue("@AssignedTo", ddlAssignment.SelectedItem.Value);
                }
                else  //We default to the user inputting the sample
                {
                    cmd.Parameters.AddWithValue("@AssignedTo", System.Web.HttpContext.Current.Session["gmID"].ToString());
                }
                cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedItem.Value);
                cmd.Parameters.Add("@scopeID", SqlDbType.Int, 0, "scopeID");
                cmd.Parameters["@scopeID"].Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();

                cmd.Dispose();
                conn.Dispose();
            }

            Response.Redirect("/Projects/ProjSamples.aspx?RTSPID=" + ddlProject.SelectedItem.Value);
        }
    }
}
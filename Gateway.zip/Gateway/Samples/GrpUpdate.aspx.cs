﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections; // this enables ArrayList
using System.Data.SqlClient; // this enables SqlConnection and SqlCommand
using System.Data; // this enables CommandType
using System.Configuration; // this enables ConfigurationManager
using System.Text; // this enables StringBuilder

namespace Gateway.Samples
{
    public partial class GrpUpdate : System.Web.UI.Page
    {
        public string RTSPID { get; set; }
        public DateTime thisDate { get; set; }
        public string grpMember { get; set; }
        public string Abrvs { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            RTSPID = HttpUtility.UrlDecode(Request.QueryString["RTSPID"]);
            HiddenField1.Value = RTSPID.ToString().Trim();
            grpMember = System.Web.HttpContext.Current.Session["NIHID"].ToString();
            List<string> myAbrvs = new List<string>();
            myAbrvs = (List<string>)Session["myAbrvs"];
            Abrvs = "";
            //string Abrvs = string.Join(",", myAbrvs.ToArray());

            foreach (string item in myAbrvs)
            {
                if (Abrvs.Length > 1)
                {
                    Abrvs += ", ";
                }
                //Abrvs += "'" + item + "'";
                Abrvs += "'" + item + "'";
            }
            //HiddenField2.Value = Abrvs;


            if (!IsPostBack)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
                string sqlString = "SELECT EnteredOn FROM tblProjSample WHERE RTSPID = @ID";
                SqlCommand sqlComm = new SqlCommand(sqlString, conn);
                sqlComm.Parameters.Add(new SqlParameter("@ID", RTSPID));
                conn.Open();

                SqlDataReader reader = sqlComm.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    {
                        thisDate = Convert.ToDateTime(reader.GetValue(0).ToString());
                    }
                }
                reader.Dispose();


                ddlAssignment.AppendDataBoundItems = true;
                sqlString = "SELECT tblGroupMember.gmID, tblGroupMember.nameFirst + ' (' + tblGroup.Abrv + ')' AS AbvName FROM tblGroupMember INNER JOIN tblGroup ON tblGroupMember.grpID = tblGroup.grpID WHERE Inactive = 'False' ORDER BY AbvName";
                sqlComm = new SqlCommand(sqlString, conn);

                ddlAssignment.DataSource = sqlComm.ExecuteReader();
                ddlAssignment.DataTextField = "AbvName";
                ddlAssignment.DataValueField = "gmID";
                ddlAssignment.DataBind();

                reader.Dispose();
                sqlComm.Dispose();
                conn.Close();


                ddlProject.AppendDataBoundItems = true;
                sqlString = "Select [Name], RTSPID FROM tblProject ORDER BY Name";
                conn.Open();
                sqlComm = new SqlCommand(sqlString, conn);
                try
                {
                    ddlProject.DataSource = sqlComm.ExecuteReader();
                    ddlProject.DataTextField = "Name";
                    ddlProject.DataValueField = "RTSPID";
                    ddlProject.DataBind();
                    ddlProject.SelectedValue = RTSPID;
                }
                finally
                {
                    conn.Close();
                }

                //Bind the Gridview
                gvbind();
                

                //sqlString = "SELECT tblProjSample.RTSSID, tblProjSample.Name FROM tblGroup INNER JOIN tblGroupMember ON tblGroup.grpID = tblGroupMember.grpID RIGHT OUTER JOIN tblProjSample ON tblGroupMember.gmID = tblProjSample.AssignedTo WHERE (tblProjSample.RTSPID = @RTSPID) AND tblGroup.Abrv IN (" + Abrvs + ") ORDER BY tblProjSample.RTSSID"; //AND (tblGroup.Abrv IN (@Abrvs) 
                //sqlComm = new SqlCommand(sqlString, conn);
                //sqlComm.Parameters.AddWithValue("@RTSPID", RTSPID);
                //sqlComm.Parameters.AddWithValue("@Abrvs", Abrvs);
                //conn.Open();
                //SqlDataSource1.SelectCommand = sqlComm.ExecuteReader();
                //reader = sqlComm.ExecuteReader();

                //int j = 0;
                //if (reader.HasRows) 
                //{
                //    while (reader.Read())
                //    {
                //        //check1.Items.Add(new ListItem(reader.GetValue(1).ToString(), reader.GetValue(0).ToString()));
                //        j++;
                //    }
                //}

                //double x = Math.Sqrt(j);
                //check1.RepeatColumns = Convert.ToInt32(x);

                //reader.Close();
                //conn.Close();


                int intDay = (thisDate.Day);
                int intMonth = (thisDate.Month);
                int intYear = (thisDate.Year);

                for (var i = 1; i < 13; i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlDeliveredM.Items.Add(item);

                    if (i == intMonth)
                    {
                        ddlDeliveredM.SelectedIndex = i;
                    }
                }

                for (var i = 1; i < 32; i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlDeliveredD.Items.Add(item);

                    if (i == intDay)
                    {
                        ddlDeliveredD.SelectedIndex = i;
                    }
                }

                for (var i = intYear; i < (intYear + 3); i++)
                {
                    var item = new ListItem
                    {
                        Text = i.ToString("D2"),
                        Value = i.ToString("D2")
                    };
                    ddlDeliveredY.Items.Add(item);

                    if (i == intYear)
                    {
                        ddlDeliveredY.SelectedIndex = ((intYear + 1) - intYear);
                    }
                }
            }
        }


        protected void gvbind()
        {
            //Get the allowed Samples and put them in the Gridview
            SqlDataSource SqlDataSource1 = new SqlDataSource();
            SqlDataSource1.ID = "SqlDataSource1";
            this.Page.Controls.Add(SqlDataSource1);
            SqlDataSource1.SelectParameters.Clear();
            SqlDataSource1.ConnectionString = ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString;
            SqlDataSource1.SelectCommand = "SELECT tblProjSample.RTSSID, tblProjSample.Name, tblGroupMember.nameFirst + ' (' + tblGroup.Abrv + ')' AS AbvName, tblGroup.Abrv FROM tblGroup INNER JOIN tblGroupMember ON tblGroup.grpID = tblGroupMember.grpID RIGHT OUTER JOIN tblProjSample ON tblGroupMember.gmID = tblProjSample.AssignedTo WHERE (tblProjSample.RTSPID = @RTSPID) AND tblGroup.Abrv IN (" + Abrvs + ") ORDER BY tblProjSample.RTSSID DESC";
            SqlDataSource1.SelectParameters.Add("RTSPID", RTSPID);
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
        }


        protected void EditButton_Click(object sender, EventArgs e)
        {
            //List<string> selectedValues = check1.Items.Cast<ListItem>()
            //.Where(li => li.Selected)
            //.Select(li => li.Value)
            //.ToList();


            if (Page.IsValid)
            {
                string Name = "";
                string Notes = "";
                string RecBy = "";
                string Pid = ddlProject.SelectedItem.Value;
                string Received = ddlDeliveredM.SelectedValue + "/" + ddlDeliveredD.SelectedValue + "/" + ddlDeliveredY.SelectedValue;
                string AsgnTo = "";
                if (ddlAssignment.SelectedItem.Value != "")  //DropDown was selected
                {
                    AsgnTo = ddlAssignment.SelectedItem.Value;
                }
                else  //We default to the user inputting the sample
                {
                    AsgnTo = System.Web.HttpContext.Current.Session["gmID"].ToString();
                }
                string Status = "";
                if (ddlStatus.SelectedItem.Value != "")  //DropDown was selected
                {
                    Status = ddlStatus.SelectedItem.Value;
                }


                //foreach (string sid in selectedValues)  //Loop through the selected Samples

                CheckBox ChkBoxHeader = (CheckBox)GridView1.HeaderRow.FindControl("chkboxSelectAll");
                foreach (GridViewRow row in GridView1.Rows)
                {
                    string RTSSID;
                    CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkEmp");
                    
                    if (ChkBoxRows.Checked == true)
                    {
                        //if (row.RowType == DataControlRowType.DataRow)
                        //{
                        RTSSID = row.Cells[1].Text.ToString();
                        //RTSSID = row.FindControl("RTSSID").ToString();
                        //}
                        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
                        string thisStatus = Status;

                        string sqlString = "SELECT Name, Notes, recBy, Status FROM tblProjSample WHERE RTSSID = @ID";
                        SqlCommand sqlComm = new SqlCommand(sqlString, conn);
                        sqlComm.Parameters.Add(new SqlParameter("@ID", RTSSID));
                        conn.Open();

                        SqlDataReader reader = sqlComm.ExecuteReader();
                        if (reader.HasRows)
                        {
                            reader.Read();
                            {
                                Name = reader.GetValue(0).ToString();
                                Notes = reader.GetValue(1).ToString();
                                RecBy = reader.GetValue(2).ToString();
                                if (Status == "")
                                { thisStatus = reader.GetValue(3).ToString(); }
                            }
                        }
                        reader.Dispose();
                        conn.Close();


                        SqlCommand cmd = conn.CreateCommand();
                        cmd.CommandText = "sproc_EditSample";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@RTSSID", RTSSID);
                        cmd.Parameters.AddWithValue("@RTSPID", ddlProject.SelectedItem.Value);
                        cmd.Parameters.AddWithValue("@Name", Name);
                        cmd.Parameters.AddWithValue("@Notes", Notes);
                        cmd.Parameters.AddWithValue("@recDate", Received);
                        cmd.Parameters.AddWithValue("@recBy", RecBy);
                        cmd.Parameters.AddWithValue("@AssignedTo", AsgnTo);
                        cmd.Parameters.AddWithValue("@Status", thisStatus);
                        cmd.Parameters.Add("@scopeID", SqlDbType.Int, 0, "scopeID");
                        cmd.Parameters["@scopeID"].Direction = ParameterDirection.Output;
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        cmd.Dispose();
                        conn.Dispose();
                    }
                }

                Response.Redirect("/Projects/ProjSamples.aspx?RTSPID=" + ddlProject.SelectedItem.Value);
            }
        }


        // Check All
        //protected void lbAll_Click(object sender, EventArgs e)
        //{
            //foreach (ListItem li in check1.Items)
            //{
                //li.Selected = true;
            //}
        //}

        // Uncheck All
        //protected void lbNone_Click(object sender, EventArgs e)
        //{
            //foreach (ListItem li in check1.Items)
            //{
                //li.Selected = false;
            //}
        //}


        protected void chkboxSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)GridView1.HeaderRow.FindControl("chkboxSelectAll");
            foreach (GridViewRow row in GridView1.Rows)
            {
                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkEmp");
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxRows.Checked = true;
                }
                else
                {
                    ChkBoxRows.Checked = false;
                }
            }
        }


        protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string item = e.Row.Cells[1].Text;
                foreach (LinkButton button in e.Row.Cells[6].Controls.OfType<LinkButton>())
                {
                    if (button.CommandName == "Delete")
                    {
                        button.Attributes["onclick"] = "if(!confirm('Do you want to delete Sample " + item + "?')){ return false; };";
                    }
                }
            }
        }


        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

            GridViewRow row = GridView1.Rows[e.RowIndex];
            int RTSSID = Convert.ToInt16(GridView1.DataKeys[e.RowIndex].Values[1]);
            
            using (SqlConnection myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString))
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
                SqlCommand cmd = conn.CreateCommand();

                cmd.CommandText = "sproc_DeleteSample";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RTSSID", RTSSID);
                cmd.Parameters.AddWithValue("@recBy", grpMember);
                cmd.Parameters.Add("@scopeID", SqlDbType.Int, 0, "scopeID");
                cmd.Parameters["@scopeID"].Direction = ParameterDirection.Output;
                conn.Open();
                cmd.ExecuteNonQuery();

                cmd.Dispose();
                conn.Dispose();

                gvbind();
            }
        }


        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            gvbind();
        }


        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            gvbind();
        }


        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            gvbind();
        }


        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int RTSSID;
            TextBox Name;
            string Notes = "";
            DateTime recDate = DateTime.Now;
            string recBy = "";
            string AssignedTo = "";
            string Status = "";

            GridViewRow row = GridView1.Rows[e.RowIndex];
            RTSSID = Convert.ToInt16(GridView1.DataKeys[e.RowIndex].Values[1]);
            Name = (TextBox)row.Cells[2].Controls[0];

            using (SqlConnection myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString))
            {
                string sqlString = "SELECT Notes, recBy, Status, recDate, AssignedTo FROM tblProjSample WHERE RTSSID = @ID";
                SqlCommand sqlComm = new SqlCommand(sqlString, myConnection);
                sqlComm.Parameters.Add(new SqlParameter("@ID", RTSSID));
                myConnection.Open();

                SqlDataReader reader = sqlComm.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    {
                        Notes = reader.GetValue(0).ToString();
                        recBy = reader.GetValue(1).ToString();
                        Status = reader.GetValue(2).ToString();
                        recDate = Convert.ToDateTime(reader.GetValue(3).ToString());
                        AssignedTo = reader.GetValue(4).ToString();
                    }
                }
                reader.Dispose();
                myConnection.Close();
            }


            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
            SqlCommand cmd = conn.CreateCommand();

            cmd.CommandText = "sproc_EditSample";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@RTSSID", RTSSID);
            cmd.Parameters.AddWithValue("@RTSPID", ddlProject.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@Name", Name.Text);
            cmd.Parameters.AddWithValue("@Notes", Notes);
            cmd.Parameters.AddWithValue("@recDate", recDate);
            cmd.Parameters.AddWithValue("@recBy", grpMember);
            cmd.Parameters.AddWithValue("@AssignedTo", AssignedTo);
            cmd.Parameters.AddWithValue("@Status", Status);
            cmd.Parameters.Add("@scopeID", SqlDbType.Int, 0, "scopeID");
            cmd.Parameters["@scopeID"].Direction = ParameterDirection.Output;

            conn.Open();
            cmd.ExecuteNonQuery();

            cmd.Dispose();
            conn.Dispose();

            GridView1.EditIndex = -1;
            gvbind();
        }


        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Projects/ProjSamples.aspx?RTSPID=" + RTSPID);
        }


    }
}
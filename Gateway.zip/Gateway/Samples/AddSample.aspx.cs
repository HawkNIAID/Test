﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Gateway.Samples
{
    public partial class AddSample : System.Web.UI.Page
    {
        public string RTSPID { get; set; }
        public string Today { get; set; }
        public string grpMember { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            RTSPID = HttpUtility.UrlDecode(Request.QueryString["RTSPID"]);
            grpMember = System.Web.HttpContext.Current.Session["NIHID"].ToString();
            Today = DateTime.Now.ToShortDateString();
            int intDay = (DateTime.Now.Day);
            int intMonth = (DateTime.Now.Month);
            int intYear = (DateTime.Now.Year);

            for (var i = 1; i < 13; i++)
            {
                var item = new ListItem
                {
                    Text = i.ToString("D2"),
                    Value = i.ToString("D2")
                };
                ddlDeliveredM.Items.Add(item);

                if (i == intMonth)
                {
                    ddlDeliveredM.SelectedIndex = i;
                }
            }

            for (var i = 1; i < 32; i++)
            {
                var item = new ListItem
                {
                    Text = i.ToString("D2"),
                    Value = i.ToString("D2")
                };
                ddlDeliveredD.Items.Add(item);

                if (i == intDay)
                {
                    ddlDeliveredD.SelectedIndex = i;
                }
            }

            for (var i = intYear; i < (intYear + 3); i++)
            {
                var item = new ListItem
                {
                    Text = i.ToString("D2"),
                    Value = i.ToString("D2")
                };
                ddlDeliveredY.Items.Add(item);

                if (i == intYear)
                {
                    ddlDeliveredY.SelectedIndex = ((intYear + 1) - intYear);
                }
            }

            ddlProject.AppendDataBoundItems = true;
            string sqlString = "Select [Name], RTSPID FROM tblProject ORDER BY Name";
            string connString = ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString;
            SqlConnection sqlConn = new SqlConnection(connString);
            SqlCommand sqlComm = new SqlCommand(sqlString, sqlConn);

            try
            {
                sqlConn.Open();
                ddlProject.DataSource = sqlComm.ExecuteReader();
                ddlProject.DataTextField = "Name";
                ddlProject.DataValueField = "RTSPID";
                ddlProject.DataBind();
                ddlProject.SelectedValue = RTSPID;
            }

            finally
            {
                sqlConn.Close();
                sqlConn.Dispose();
            }
        }

        protected void AddButton_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                Object returnValue;
                string strID = "";
                string Received = ddlDeliveredM.SelectedValue + "/" + ddlDeliveredD.SelectedValue + "/" + ddlDeliveredY.SelectedValue;

                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString);
                SqlCommand cmd = conn.CreateCommand();

                cmd.CommandText = "sproc_AddSample";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@RTSPID", ddlProject.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@Name", txtSampleName.Text);
                cmd.Parameters.AddWithValue("@Notes", txtNotes.Text);
                cmd.Parameters.AddWithValue("@recDate", Received);
                cmd.Parameters.AddWithValue("@recBy", grpMember);
                cmd.Parameters.AddWithValue("@AssignedTo", System.Web.HttpContext.Current.Session["gmID"].ToString()); 
                cmd.Parameters.AddWithValue("@Status", "Received");

                conn.Open();
                //returnValue = ""; //for testing
                returnValue = cmd.ExecuteScalar();

                cmd.Dispose();
                conn.Dispose();


                strID = returnValue.ToString();
                //strID = ""; //for testing

                if (strID != "")
                {
                    string strHTML = "<HTML>";
                    strHTML += "<HEAD>";
                    strHTML += "<BODY>";
                    strHTML += "<b>A new Animal Request has been submitted online.</b><br><br>";
                    strHTML += "Please <a href='http://rmlanimals.niaid.nih.gov/OrderAdmin/ApproveEntry.aspx?RequestID=" + strID + "'>click here</a> to review the request.<br>";
                    strHTML += "<br><br><a href='http://rmlanimals.niaid.nih.gov/OrderAdmin/Unapproved.aspx'>All Pending Orders</a><br>";
                    strHTML += "</BODY>";
                    strHTML += "</HTML>";


                    try
                    {

                        //CDO.Message mymail = new CDO.Message();
                        //CDO.IConfiguration configuration = mymail.Configuration;
                        //ADODB.Fields fields = configuration.Fields;

                        //mymail.Subject = "New Animal Request";
                        //mymail.From = "hawk.chilcote@nih.gov";
                        //mymail.To = "ddale@niaid.nih.gov; rlacasse@niaid.nih.gov; rrivera@niaid.nih.gov; hawk.chilcote@nih.gov";
                        //mymail.To = "hawk.chilcote@nih.gov";
                        //mymail.HTMLBody = strHTML;

                        //ADODB.Field field = fields["http://schemas.microsoft.com/cdo/configuration/smtpserver"];
                        //field.Value = "127.0.0.1";

                        //field = fields["http://schemas.microsoft.com/cdo/configuration/smtpserverport"];
                        //field.Value = 25;

                        //field = fields["http://schemas.microsoft.com/cdo/configuration/sendusing"];
                        //field.Value = 2;

                        //field = fields["http://schemas.microsoft.com/cdo/configuration/smtpauthenticate"];
                        //field.Value = CDO.CdoProtocolsAuthentication.cdoBasic;

                        //fields.Update();
                        //mymail.Send();
                    }
                    catch (Exception ex)
                    {
                        Label1.Text = ex.ToString();
                    }

                    //Response.Redirect("RequestAckn.aspx?ID=" + strID);
                    //Response.Redirect("Index.aspx");
                    Response.Redirect("/Projects/ProjSamples.aspx?RTSPID=" + ddlProject.SelectedItem.Value);
                }
            }
        }
    }
}
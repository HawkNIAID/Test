﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Gateway.Samples
{
    public partial class ListSamples : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Grid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strID = GridView1.SelectedDataKey.Value.ToString();
            Response.Redirect("EditSample.aspx?RTSSID=" + strID);
        }
    }
}
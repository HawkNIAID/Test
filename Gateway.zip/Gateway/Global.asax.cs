﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using System.Web.Security;
using System.Data.SqlClient; // this enables SqlConnection and SqlCommand
using System.Data; // this enables CommandType
using System.Configuration; // this enables ConfigurationManager
using Gateway;

namespace Gateway
{
    public class Global : HttpApplication
    {

        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            AuthConfig.RegisterOpenAuth();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
        }

        void Application_End(object sender, EventArgs e)
        {
            //  Code that runs on application shutdown

        }

        void Application_Error(object sender, EventArgs e)
        {
            // Code that runs when an unhandled error occurs

        }

        void Session_OnStart()
        {
            Session["NIHID"] = Environment.UserName;
            string myName = "";
            string gmID = "";
            string group = "";
            List<string> myAbrvs = new List<string>();


            if (!string.IsNullOrEmpty(System.Web.HttpContext.Current.Session["NIHID"].ToString()))
            {
                string connString = ConfigurationManager.ConnectionStrings["RTSConnectionString"].ConnectionString;
                string sqlString = "SELECT tblGroupMember.nameFirst, tblGroup.Abrv, tblGroupMember.gmID FROM tblGroupMember INNER JOIN tblGroup ON tblGroupMember.grpID = tblGroup.grpID WHERE NIHID = @strID";
                SqlConnection sqlConn = new SqlConnection(connString);
                SqlCommand sqlComm = new SqlCommand(sqlString, sqlConn);
                sqlComm.Parameters.AddWithValue("@strID", Session["NIHID"].ToString());
                sqlConn.Open();
                SqlDataReader reader = sqlComm.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    {
                        myName = reader.GetValue(0).ToString();
                        group = reader.GetValue(1).ToString();
                        gmID = reader.GetValue(2).ToString();
                    }
                }
                reader.Close();
                sqlConn.Close();


                //Set Session variables
                if (Session["myName"] == null)
                {
                    Session["myName"] = myName;
                }

                if (Session["group"] == null)
                {
                    Session["group"] = group;
                }

                if (Session["gmID"] == null)
                {
                    Session["gmID"] = gmID;
                }

                if (Session["myAbrvs"] == null)
                {
                    sqlString = "SELECT tblGroup.Abrv FROM tblGroupMember INNER JOIN tblGroup ON tblGroupMember.grpID = tblGroup.grpID WHERE (tblGroupMember.Inactive = 'False' AND tblGroupMember.NIHID = @strID)";
                    sqlComm = new SqlCommand(sqlString, sqlConn);
                    sqlComm.Parameters.AddWithValue("@strID", Session["NIHID"].ToString());
                    sqlConn.Open();
                    reader = sqlComm.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            myAbrvs.Add(reader.GetValue(0).ToString());
                        }
                    }
                    reader.Close();
                    sqlConn.Close();

                    Session["myAbrvs"] = myAbrvs;
                }
            }
        }
    }
}

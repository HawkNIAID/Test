﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Gateway
{
    public partial class Change : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Request.UrlReferrer != null) ViewState["PreviousPageUrl"] = Request.UrlReferrer.ToString();

                List<string> myAbrvs = new List<string>();
                myAbrvs = (List<string>)Session["myAbrvs"];

                if (myAbrvs.Count > 1)
                {
                    foreach (string grp in myAbrvs)
                    {
                        RadioButtonList1.Items.Add(new ListItem(grp, grp));
                        if (Session["group"].ToString() == grp)
                        {
                            RadioButtonList1.Items.FindByValue(grp).Selected = true;
                        }
                    }
                }
            }
        }


        protected void Commit_ServerClick(object sender, System.EventArgs e)
        {
            string newGroup = RadioButtonList1.SelectedItem.Value;
            Session["group"] = newGroup;

            //if (ViewState["PreviousPageUrl"] == null)
            //{
            //    ViewState["PreviousPageUrl"] = "~/Default.aspx";
            //}

            //Response.AddHeader("REFRESH", "2;URL=" + ViewState["PreviousPageUrl"].ToString());

            Response.Redirect(ViewState["PreviousPageUrl"] != null ? ViewState["PreviousPageUrl"].ToString() : "~/Default.aspx");
        }
    }
}